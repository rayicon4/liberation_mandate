<!-- //custom-theme -->
  <meta property="og:url"           content="<?php echo  $absolute_url;?>" />
  <meta property="og:type"          content="website" />
  <meta property="og:title"         content="<?php echo  $title;?>" />
  <meta property="og:description"   content="NGO, Liberators Mandate" />
  <meta property="og:image"         content="images/1.jpg" />
  <link href="../favicon.ico" rel="shortcut icon" type="image/x-icon" media="all" />
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- js -->
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<!-- //js -->
<!-- font-awesome-icons -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome-icons -->
<link href="//fonts.googleapis.com/css?family=Oswald:300,400,700&amp;subset=latin-ext" rel="stylesheet">
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>