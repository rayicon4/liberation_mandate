<!-- subscribe -->
	<div class="footer-top">
		<div class="container">
			<div class="col-md-7 welcome">
				<h3>Liberation Mandate: MANIFESTO</h3>

				<p>
In consideration of the dwindling democratic system in Abia state, it is our resolution to readdress and enthrone a viable social democratic system which requires an active and participating civil society. As a consequence therefore, all patriotic citizens of Abia must come together to rebuild the foundations of our civil society. Social critics, civilians and politicians alike at this stage of our struggle for the enthronement of democracy and human rights together with social justice are convinced that this manifesto contains what is required for the success of democracy in Abia state propelled by our energetic and dynamic platform, LIBERATORS MANDATE, We hereby resolve:</p>
				
			</div>
			
			<div class="col-md-5 wthree-subscribe">
				<h3>Newsletter </h3>
				<p>Receive the latest useful information, daily.</p>
				<div class="w3-agileits-subscribe-form">
					<form action="#" method="post">
						<input type="text" placeholder="Email" name="Subscribe" required="">
						<button class="btn1">Subscribe</button>
					</form>
				</div>
				<div class="agile_header_social">
					<ul class="agileits_social_list">
						<li><a href="https://www.facebook.com/Liberatorsmandate/" class="w3_agile_facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
						<li><a href="#" class="agile_twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
						<li><a href="https://wa.me/2348060630925/?Welcome" class="w3_agile_dribble"><i class="fa fa-whatsapp" aria-hidden="true"></i></a></li>
						<li><a href="#" class="w3_agile_vimeo"><i class="fa fa-vimeo" aria-hidden="true"></i></a></li>
					</ul>
				</div>
			</div>
				<div class="clearfix"></div>
		</div>
	</div>
<!-- //subscribe -->
<!-- copy-right -->
	<div class="copy-right-grids">
		<div class="container">
			<div class="copy-left">
				<p class="footer-gd">© 2017 Liberation Mandate. All Rights Reserved | Design by <a href="" target="_blank">Flexsummer.ng</a></p>
			</div>
				<div class="clearfix"></div>
		</div>
	</div>