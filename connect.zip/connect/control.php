<?php
require_once('connect.php');

class liberator extends DB{
			
	var $db_centers = 'db_centers';
	var $db_users = 'db_users';
	var $db_datas = 'datas';
	var $db_winners = 'db_wins';

	protected function ()
	{
		
	}	
	
}




?>