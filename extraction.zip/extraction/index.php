<?php
header('location:home/index.php');

?>