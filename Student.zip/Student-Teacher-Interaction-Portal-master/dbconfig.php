<?php
$conn=mysqli_connect("localhost","root","","questions")or die(mysqli_error());
?>
