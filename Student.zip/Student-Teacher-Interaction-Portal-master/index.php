<?php header( 'Location: /home2.php' ) ;  ?>
