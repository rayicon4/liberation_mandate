* https://stackoverflow.com/questions/20654848/html-php-display-username-after-success-login
* https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTkc6bEv5qiRtZ8QflFBdAhExoyiHzX6vZfDAZOj8SSBrg_LOE2
* https://stackoverflow.com/questions/9262861/css-background-image-to-fit-width-height-should-auto-scale-in-proportion
* https://stackoverflow.com/questions/23493774/not-getting-file-type-and-tmp-name-while-uploading
