# Student-Teacher-Interaction-Portal
A web-portal to make interaction between student-teacher feasible.

<!-- [View website here](https://workpurpose.000webhostapp.com) -->

### Functionalities Added
- [x] Course Registration
- [x] Assignment upload/submission
- [x] Q-A Forum
- [x] View/Download study Material
- [x] Student Feedback
- [x] Attendence
- [ ]  Fees Payment
- [ ]   Placement module

