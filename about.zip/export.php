<html>
<head>

</head>
<body>
  <div class="container">
    <br />
    <br />
    <br />
    <div class="table-responsive">
      <h2 align="center">Export MSQL data to Excel in PHP</h2><br />
      <div id="live_data"></div>
      <form action="excel.php" method="post">
        <input type="submit" name="export_excel" class="btn btn-success" value="Export to Excel" />
      </form>
    </div>
  </div>

</body>

</html>
